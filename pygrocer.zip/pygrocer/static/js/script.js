$(document).ready(function () {
    $("#newItem").hide();
    $("#inven").hide();
    $("#printPage").hide();

    $("#newItemBtn").click(function () {
        $("#home").hide();
        $(".metricvUnit").show()
        $(".amimvUnit").hide()
        $(".amimwUnit").hide()
        $(".metricwUnit").hide()
        $("#newItem").show();
        
        $("#mVol").click(function () {
            $(".metricvUnit").show()
            $(".amimvUnit").hide()
            $(".amimwUnit").hide()
            $(".metricwUnit").hide()  
        })
        $("#mWei").click(function () {
            $(".metricvUnit").hide()
            $(".amimvUnit").hide()
            $(".amimwUnit").hide()
            $(".metricwUnit").show()  
        })
        $("#aVol").click(function () {
            $(".metricvUnit").hide()
            $(".amimvUnit").show()
            $(".amimwUnit").hide()
            $(".metricwUnit").hide()  
        })
        $("#aWei").click(function () {
            $(".metricvUnit").hide()
            $(".amimvUnit").hide()
            $(".amimwUnit").show()
            $(".metricwUnit").hide()  
        })
    });

    $("#invenBtn").click(function () {
        $("#home").hide()
        $("#inven").show()
        
    })
     $("#printPageBtn").click(function () {
        $("#home").hide()
        $("#printPage").show()
        
    })
    $("#niGoBack").click(function () {
        $("#home").show()
        $("#newItem").hide()
        $("#inven").hide()
        $("#printPage").hide()
        
    })
    $("#inGoBack").click(function () {
        $("#home").show()
        $("#newItem").hide()
        $("#inven").hide()
        $("#printPage").hide()
    })
    $("#ppGoBack").click(function () {
        $("#home").show()
        $("#newItem").hide()
        $("#inven").hide()
        $("#printPage").hide()
    })
})
